# Pre-Submission QA Checklist

Last checked: 2026-04-22

## Automated/static checks (completed)

- Lint checks on modified files passed.
- Global extension ON/OFF wiring is consistent across:
  - `background.js`
  - `popup.js`
  - `content.js`
  - `injected.js`
- Draft/session UX wiring includes explicit `Unsaved Draft` option and supports selecting draft mode.
- Record capture supports JSON and text responses in `injected.js`.

## Manual QA (must run in Chrome before store submit)

1. Extension toggle:
   - Turn OFF in popup and verify:
     - on-page header disappears
     - replay does not mock
     - record does not capture
   - Turn ON and verify behavior resumes.
2. Session lifecycle:
   - Record APIs without saving and verify `Unsaved Draft` appears.
   - Click `Save Draft as Session`, verify session appears in dropdown.
   - Switch session, rename, delete, and re-select `Unsaved Draft`.
3. API capture coverage:
   - Validate GET/POST/PUT/PATCH/DELETE capture.
   - Validate JSON and text response capture.
   - Validate replay returns stored responses correctly.
4. Long URL list behavior:
   - Confirm list rows remain one line with ellipsis.
   - Confirm full key appears in Selected API and tooltip.
5. Branding and icons:
   - Confirm popup logo appears.
   - Confirm pinned toolbar icon updates after extension reload.
