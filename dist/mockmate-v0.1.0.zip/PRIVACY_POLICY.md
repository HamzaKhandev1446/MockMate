# MockMate Privacy Policy

Last updated: 2026-04-22

MockMate is a developer tool that records and replays API responses in your browser for local testing.

## What data MockMate accesses

- Request metadata for API calls made by the active web page (for example: URL, method).
- Response data for calls captured in Record mode (status, headers, body content).
- Extension settings and saved mock sessions.
- Active tab information needed to scope state to the current site.

## How data is stored

- MockMate stores data locally in your browser using `chrome.storage.local`.
- MockMate does not use a remote database or cloud account for extension data.

## How data is used

- To let you record, edit, and replay API responses during development/testing.
- To render extension UI state (modes, sessions, delays, toggles) and on-page banner status.

## Data sharing

- MockMate does not sell your data.
- MockMate does not transmit captured API data to MockMate-owned servers.
- If you use features that call your own API endpoints from the extension (for example, endpoint fetch/import helpers), requests are sent only to the destination URL you provide.

## User control

- You can disable extension behavior globally using the ON/OFF toggle.
- You can clear session data and delete saved sessions from the popup UI.
- Removing the extension removes access to the extension features.

## Permissions rationale

- `storage`: save settings, sessions, and mock data locally.
- `tabs`: scope state and sync behavior for the active tab/site.
- `contextMenus`: support "Add to MockMate" context menu actions.
- `host_permissions` (`<all_urls>`): required to run as a general-purpose API mocking tool across developer test environments.

## Contact

For policy questions, use your project support channel or repository issue tracker.
