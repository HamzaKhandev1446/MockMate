# Chrome Web Store Submission Checklist

## 1) Build release ZIP

From project root:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\package-extension.ps1
```

Expected output package:

- `dist/mockmate-v<version>.zip`

## 2) Prepare listing assets

- 128x128 icon (export PNG if needed by store UI)
- At least one screenshot (`1280x800` or `640x400`)
- Optional promo images (small/large/marquee)

## 3) Compliance

- Privacy policy URL published from `PRIVACY_POLICY.md` content
- Data disclosure form filled consistently with actual behavior:
  - local storage only (`chrome.storage.local`)
  - captures URL/method/response data for mocking workflows
  - no sale of user data

## 4) Store metadata

- Name/summary/description aligned with `MockMate` branding
- Category and language selected
- Permission justifications ready (`storage`, `tabs`, `contextMenus`, `<all_urls>`)

## 5) Submit in dashboard

1. Open <https://chrome.google.com/webstore/devconsole/>
2. Upload `dist/mockmate-v<version>.zip`
3. Fill listing + privacy tabs
4. Submit for review

## 6) Expected timeline

- Typical review: 3-10 business days
- Can be faster (1-3 business days) for straightforward updates
- Resubmission after policy feedback may add 3-14 business days
